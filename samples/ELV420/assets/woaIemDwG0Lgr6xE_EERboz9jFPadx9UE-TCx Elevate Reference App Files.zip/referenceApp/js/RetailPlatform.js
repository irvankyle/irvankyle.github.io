/**
 * @license
 * Copyright (c) 2014 Toshiba Global Commerce Solutions Holdings Corporation and
 *           (c) 2019 Toshiba Tec Corporation. All Rights Reserved.
 *
 * Use of this source code is governed by a [type of license] licencse that can be
 * found in the LICENSE file at https://www.toshibagcs.com/license
 */

/**
 * RetailPlatform.js v1.4 - Added support for 4690 build 1910+ and TCx Sky SP2+
 * Import this file into any web page need to use the Javascript POS bridge.
 */
var retailPlatformVersion = "1.4";

function parentWindow() {
    if ( retailPlatformParent ) {
        return retailPlatformParent;
    }
    var parentWindow = window;
    // Trying to navigate to the top window fails on browser versions 60+, 
    // keep navigating up in the hierarchy until one window below the top: 
    while ( parentWindow.parent != top ) {
        parentWindow = parentWindow.parent;
    }
    retailPlatformParent = parentWindow;
    return retailPlatformParent;
} 

var retailPlatformParent = parentWindow();

function __severe( msg, exception ) {
    if ( typeof( exception ) == "undefined" ) {
        alert( "Severe exception occurred: " + msg );
    } else {
        if ( typeof( exception.message ) == "undefined" ) {
            alert( "Severe exception occurred (no .message component): " + msg + ": " + exception );
        } else {
            alert( "Severe exception occurred: " + msg + ": " + exception.message );
        }
    }
}

function RetailPlatformException( exceptionCode, errorCode, extendedErrorCode, exceptionMessage ) {
    try {
        this.IS_RETAIL_PLATFORM_EXCEPTION = true;
        this.result = "failure";
        this.exceptionCode = exceptionCode;
        this.errorCode = errorCode;
        this.extendedErrorCode = extendedErrorCode;
        this.exceptionMessage = exceptionMessage;
        this.message = this.exceptionMessage; // common JavaScript exception field
    } catch ( e ) {
        __severe( "Error creating exception object", e );
    }
}

function RetailPlatform() {
    /**
   * RetailPlatformHook is a Java method exposed by the web browser. 
   * It is the gateway to all other Java methods meant to be 
   * bridged to JavaScript. It will be available only in the 
   * topmost window object, so only access it via the top instance of 
   * RetailPlatformHook accessed through retailPlatformParent.
   */

    if ( ( typeof retailPlatformParent.RetailPlatformHook ) != "function" ) {
        //alert( "Browser function not found: RetailPlatformHook . You may not be running within Expeditor or may have attempted to initialize the platform prior to the onload DOM event" );
        throw new RetailPlatformException( 100, 1, 2, "Browser function not found: RetailPlatformHook . You may not be running within Expeditor or may have attempted to initialize the platform prior to the onload DOM event" );
    }
    
    /**
   * _windowJS and _platformConstructor will formulate a string which will define the rest of the 
   * global JavaScript and RetailPlatform object.
   * This is done to avoid putting too much code into the JavaScript library.
   * When done this way, the same JavaScript library can be used for 
   * differing versions of the retail stack.
   */
    eval.apply( window, [ retailPlatformParent.RetailPlatformHook( "_windowJS", RetailPlatform.client ) ] );
    eval( retailPlatformParent.RetailPlatformHook( "_platformConstructor", RetailPlatform.client ) );
}

function __tryPlatformReset(platform) {
    if ( retailPlatformParent.RetailPlatform.resetFlag ) {
        platform.reset();
        retailPlatformParent.RetailPlatform.resetFlag = false;
    }
}

// Create a static method to retrieve the platform object
var __rplatform = null;
RetailPlatform.getInstance = function() {
    if ( retailPlatformParent == self ) {
        if ( retailPlatformParent.__rplatform != null ) {
            __tryPlatformReset(retailPlatformParent.__rplatform)
            return retailPlatformParent.__rplatform;
        }
        retailPlatformParent.__rplatform = new RetailPlatform();
        __tryPlatformReset(retailPlatformParent.__rplatform);
        return retailPlatformParent.__rplatform;
    } else {
        return retailPlatformParent.RetailPlatform.getInstance();
    }
}

function __checkReady( timeout ) {
    if ( timeout < 0) {
        RetailPlatform.onReadyMethod( new RetailPlatformException( 100, 1, 1, "Timeout initializing platform" ) );
        return;
    }

    if ( ( typeof retailPlatformParent.RetailPlatformHook ) != "function" ) {
        timeout-=500;
        setTimeout( "__checkReady(" + timeout + ")", 500 );
        return;
    } 

    var result = retailPlatformParent.RetailPlatformHook( "testMethod", RetailPlatform.client, "ready" );
    if ( result != "ready" ) {
        timeout-=500;
        setTimeout( "__checkReady(" + timeout + ")", 500 );
        return;
    }
    
    // Copy parameters from current window into top window (this could be different if the API is being used in an iframe)
    retailPlatformParent.RetailPlatform.client = RetailPlatform.client;
    retailPlatformParent.RetailPlatform.onReadyMethod = RetailPlatform.onReadyMethod;
    retailPlatformParent.RetailPlatform.resetFlag = true; // notify RetailPlatform.getInstance that a reset is required for this client
    retailPlatformParent.RetailPlatform.onReadyMethod( { "result" : "success" } );
}

/**
 * Page authors must call onReady with a client name and the method they want invoked when the
 * platform is ready for use. Their method will be invoked and the first
 * argument will be the platform instance;
 */
RetailPlatform.onReady = function( client, method, timeout ) {
    if ( ( typeof client )  != "string" ) {
        throw new RetailPlatformException( 200, 1, 1, "onReady argument 1 must be a client name string" );
    }

    if ( ( typeof method ) == "string" ) {
        method = eval( method );
    }

    if ( (typeof method) != "function" ) {
        throw new RetailPlatformException( 200, 1, 2, "onReady argument 2 must be a method name or a method reference" );
    }

    if ( ( typeof retailPlatformParent.RetailPlatform ) == "undefined" ) {
        throw new RetailPlatformException( 200, 1, 3, "RetailPlatform.js is not being included in the top window. Unable to initialize the API." );
    }

    if ( ( typeof timeout ) != "number" ) {
        timeout = 30000;
    }

    RetailPlatform.client = client;
    RetailPlatform.onReadyMethod = method;
    __checkReady( timeout );
}

